#include <string>
#include <iostream>
#include <thread> //�����带 ���� �������
#include <vector>
#include <algorithm>
#include <string>
#include <cstdio>
#include <random>
#include <windows.h>
#include <math.h>
#include <gl/glut.h>
#include <fstream>

using namespace std;
struct liner {
	int startX;
	int startY;
	int endX;
	int endY;

};

bool half_flag = false;
int adder = 0;
int quantization = 0;
int capture_counter = 0;
ofstream fout;

int command_color = -1;//���ɾ� ����� �ش� ���� ���򺯰�;

int checker; // ���ɾ� üũ

			 // map check
int map[100][100];
int line[100][100];
int NON = 0; //�ƹ��͵��ƴ�
int WhiteStone = 1; //���
int BlackStone = 2; //������
int MidStone = 3;
int countt = 0;
int Door = 5; //��
int Robot = 7; //�κ�
int Finish = -1; //����� ���ɾ�
int LineStart = 9; //���ǽ���
int LineEnd = 10; //���ǳ�
				  // �ٵϾ�
bool caculate_finish = false;
bool fout_flag = false;
const float DEG2RAD = 3.14159 / 180;
float radius = 5.0;

GLsizei wh = 1000, ww = 1000;
GLsizei termW = 25, termH = 25;
GLfloat size = 5.0;

void DrawStone(int x, int y);
void myReshape(GLsizei w, GLsizei h);
void myinit();
void display();
void DoKeyboard(unsigned char key, int x, int y);

bool create_flag = false; //���� ���� �ľ�
int timer = 0;

int first_robot_x, first_robot_y = 0;
int second_robot_x, second_robot_y = 0;
int third_robot_x, third_robot_y = 0;
int forth_robot_x, forth_robot_y = 0;
struct point_vector {
	int x;
	int y;
	int weight;
	int waiting_time;
};

struct work_vector {
	int x;
	int y;
	int request;//0 - �̵� 1 ���� 2 ����
	int end_x;
	int end_y;
	int create_time; //���۽ð�
	float end_time; //���� �Ϸ�ð�
	float mov;  // ���� �̵� �Ÿ�
	float arc;
};


struct flager { //�ش� ��ǥ�� ����(
	bool is_door = false;
	bool now_robotPosition = false;
	bool now_freightPosition = false;
	bool moving_checker = false;
};

int qcounter = 0;
int hcounter = 0;
flager matrix[100][100];
vector<work_vector> work_list; // ������ ���ɾ ����Ǵ°���
vector<int> time_counter;

// fifo �� task_sorting�� �̿�
int work_counter = 0, work_size = 0; // work_counter : �� �� Ƚ��, work_size : comp_vec ������.
float index = 0, dist_moving = 0, time_moving = 0;  // index : ��ü �ð��� �� ����� ���� ����ϴ� index 
													// dist_moving , time_moving : �̵��ÿ� ���Ǵ� �Ÿ� ����� ���� ����
vector<float> full_work_time, full_work_dist;
vector<work_vector> comp_vec; // ���� ��꿡 �̿�Ǵ� ����,����ü (work_list �ջ� x�� ����)

int fifo_size = 0;

int req_0_dist = 0, req_1_dist = 0, req_2_dist = 0;
// Ȥ�ø� ������ ���� vector�� ������ ���� �Ÿ� / �����ð�

float temp_d = 0, temp_t = 0; // 0��° �Ÿ���, �ð����� ����ϱ� ���� ����

float total_dist = 0, total_time = 0; // ��ü �ð�, �Ÿ��� ����ϱ� ���� ����
float greedy_total_dist = 0, greedy_total_time = 0;
float convex_total_dist = 0, convex_total_time = 0;
float average_wating_time = 0;

//elevetor algo�� �̿�
int el_counter = 0;
int el_size = 0;
int el_idx = 0;
vector<work_vector> ele_vector;
vector<float> el_full_dist;
vector<float> el_full_time;
bool el_sort_flag = false;


// greedy best first search�� �̿�
int greedy_counter = 0;
int greedy_idx = 0;
vector<work_vector> copy_vector, copy_paste, copy_convex_paste;

vector<work_vector>copy_divider[4];
vector<work_vector>copy_random_divider[4];

vector<work_vector>row[4], col[4];
int copy_size = 0;
vector<float> greedy_full_dist;
vector<float> greedy_full_time;
vector<float> greedy_tend_vector;
bool all_sort_flag = false;

//convex hull ���� �� �̿�
int convex_counter = 0;
int convex_idx = 0;
vector<work_vector> convex_vector;
vector<float> convex_full_dist;
vector<float> convex_full_time;
int convex_size = 0;

// �׸��� �̿�
vector<work_vector> drow_vec;
vector<liner> linevec;
vector<work_vector> greedy_drow_vec;
vector<work_vector> convex_drow_vec;
vector<work_vector> el_drow_vec;
bool F_flag = false;
bool B_flag = false;
bool C_flag = false;
void renderBitmapCharacher(float x, float y, float z, void *font, const char *string)
{

	const char *c;
	glRasterPos3f(x, y, z);
	for (c = string; *c != '\0'; c++) {
		glutBitmapCharacter(font, *c);
	}
}

int font = (int)GLUT_BITMAP_8_BY_13;
int font2 = (int)GLUT_BITMAP_TIMES_ROMAN_24;
// �ʵ� Ŭ���� , make_robot�� make_door, make_freight�Լ����� ���� �Լ��� �����ϰ� ���� �ʿ�
class make_field {

public:
	vector<point_vector> robot, door, freight;
	int robot_num, door_num, freight_num;

	void make_robot() {
		cout << "�κ��� �����մϴ� " << endl;
		random_device rd;
		mt19937 mt(rd()); //�ξ� ����
		uniform_int_distribution<int> dist(4, 4);
		robot_num = dist(mt);
		cout << " �κ� ��� : " << robot_num << endl;
		point_vector temp;
		for (int i = 0; i < robot_num; i++) {
			uniform_int_distribution<int> dist2(1, 38);
			temp.x = dist2(mt);
			Sleep(1);
			temp.y = dist2(mt);
			temp.weight = 0;

			if (matrix[temp.y][temp.x].now_robotPosition == false) {
				robot.push_back(temp);
				cout << "(" << temp.x << "," << temp.y << ")��ġ�� �κ� ����" << endl;
				matrix[temp.y][temp.x].now_robotPosition = true;
			}
			else {
				// �κ� ������ �� ���� ���� �ʾ����� ������ ���� �����ϰ� ���� �Ұ�
			}

		}
	}

	void make_door() { //�񱳸� ���� ����
		cout << "���Ա��� �����մϴ�" << endl;
		random_device rd;
		mt19937 mt(rd()); //�ξ� ����
		uniform_int_distribution<int> dist(1, 1); // ���� ����
		door_num = dist(mt);
		cout << " �� ���� : " << door_num << endl;
		point_vector temp;

		uniform_int_distribution<int> dist2(0, 1); // ���� ���� ���� (0 - ����, 1-����)

		uniform_int_distribution<int> dist3(0, 39);
		/*
		for (int i = 0; i < door_num; i++) {
			int row = dist2(mt);
			int value = dist3(mt);
			if (row == 0) {
				temp.x = value;
				temp.y = 0;
				temp.weight = 0;
				door.push_back(temp);
			}
			else {
				temp.x = 0;
				temp.y = value;
				temp.weight = 0;
				door.push_back(temp);
			}
		}
		*/
		temp.x = 0; temp.y = 20; temp.weight = 0;
		door.push_back(temp);

		for (int i = 0; i < door.size(); i++) {
			matrix[door[i].x][door[i].y].is_door = true;
			cout << "( " << door[i].x << "," << door[i].y << ") ��ġ�� �� ����" << endl;

		}

	}
	void make_freight() {
		cout << "ȭ���� �����մϴ�" << endl;
		random_device rd;
		mt19937 mt(rd()); //�ξ� ����
		uniform_int_distribution<int> dist(30, 30);  // �ּ� - �ִ� ȭ���� ������ �����ϴ� �ڵ�
		freight_num = dist(mt);
		cout << "ȭ�� ���� : " << freight_num << endl;
		uniform_int_distribution<int> dist3(1, 38);


		for (int i = 0; i < freight_num; i++) {

			point_vector temp;
			temp.x = dist3(mt);
			temp.y = dist3(mt);
			temp.weight = dist3(mt);
			if (matrix[temp.y][temp.x].now_freightPosition == false) {
				freight.push_back(temp);
				cout << "(" << temp.x << "," << temp.y << ")��ġ�� ȭ�� ����" << endl;
				matrix[temp.y][temp.x].now_freightPosition = true;
			}
			else {
				freight_num--;//�ߺ���û���� ���� ���� x
			}

		}
	}

};
make_field a;


int counter = 0;

//ȭ�� ����
void DrawStone(int x, int y)
{

	x = x * 25; y = y * 25;
	x = x + 25;

	//x = x + termW;
	y = wh - y;
	//y = y + termW;

	int mapX, mapY;
	mapX = x / termW;
	mapY = y / termH;
	int tempMap = map[mapX][mapY];
	if (checker == 7) {
		map[mapX][mapY] = Robot;
	}
	else if (checker == 5) {
		map[mapX][mapY] = Door;
	}
	else if (checker == 1)
	{
		map[mapX][mapY] = WhiteStone;
		countt++;
	}
	else if (checker == 2)
	{
		map[mapX][mapY] = MidStone;
		countt++;
	}
	else {
		map[mapX][mapY] = BlackStone;
		countt++;
	}
}
int line_counter = 100;
void DrawLine(int x1, int y1, int x2, int y2) {


	x1 = x1 * 25; y1 = y1 * 25;
	x2 = x2 * 25; y2 = y2 * 25;

	x1 = x1 + 25;
	x2 = x2 + 25;
	y1 = wh - y1;
	y2 = wh - y2;
	int mapX1, mapY1, mapX2, mapY2;
	mapX1 = x1 / termW;
	mapY1 = y1 / termH;
	mapX2 = x2 / termW;
	mapY2 = y2 / termH;
	line[mapX1][mapY1] = LineStart;
	line[mapX2][mapY2] = LineEnd;
	//

}
void myReshape(GLsizei w, GLsizei h)
{
	glViewport(0, 0, w, h);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, (GLdouble)w, 0.0, (GLdouble)h, -100, 100);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	ww = w;
	wh = h;
}
void myinit()
{
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, (GLdouble)ww, 0.0, (GLdouble)wh, -1.0, 1.0);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	glFlush();
	glutReshapeFunc(myReshape);
}


int display_counter = 0;

void display()
{
	
	glClearColor(0.0, 0.0, 0.0, 1.0);
	//glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();         // Reset The Current Modelview Matrix

							  // �ٵ��� background draw
	glColor3f(0.9, 0.9, 0.9);
	glBegin(GL_POLYGON);
	//glVertex2f(termW / 3, termH / 3);
	//glVertex2f(ww - termW / 3, termH / 3);
	//glVertex2f(ww - termW / 3, wh - termH / 3);
	//glVertex2f(termW / 3, wh - termH / 3);

	glVertex2f(0, 0);
	glVertex2f(ww, 0);
	glVertex2f(ww, wh);
	glVertex2f(0, wh);
	glEnd();
	// �ٵ��� check board draw
	glColor3f(0, 0, 0);
	glLineWidth(3);
	glBegin(GL_LINE_LOOP);  // �׵θ�
	glVertex2f(termW, termH);
	glVertex2f(ww - termW, termH);
	glVertex2f(ww - termW, wh - termH);
	glVertex2f(termW, wh - termH);
	glEnd();

	glColor3f(0, 0, 1);
	glLineWidth(1);

	//string abc = to_string(greedy_total_time);
	//string def = to_string(greedy_total_dist);
	glPushMatrix();

	glColor3f(1, 0, 0);
	renderBitmapCharacher(1030, 930.0, 0, (void *)font, "Travel Distance: ");
	renderBitmapCharacher(1030, 960.0, 0, (void *)font, "Travel time: ");
	renderBitmapCharacher(1160, 400, 0, (void *)font, "AVG Wait: ");

	glColor3f(0, 0, 1);

	string time, distance,avg;
	if (B_flag == true || C_flag == true) {
		time = to_string(greedy_total_time);
		distance = to_string(greedy_total_dist);
		avg = to_string(average_wating_time);
	}

	else if (F_flag == true) {
		time = to_string(greedy_total_time);
		distance = to_string(greedy_total_dist);
		avg = to_string(average_wating_time);
	}

	else { time = "0"; distance = "0"; }
	if (fout_flag == true) {
		fout << greedy_total_dist << "\t";
		fout << avg << "\t";
	}
	//glPushMatrix()
	renderBitmapCharacher(1030, 945, 0, (void *)font, time.c_str());
	renderBitmapCharacher(1030, 915, 0, (void *)font, distance.c_str());
	renderBitmapCharacher(1170, 385, 0, (void *)font, avg.c_str());

	glColor3f(1, 0, 1);
	renderBitmapCharacher(1030, 900, 0, (void *)font, "Travel route: ");
	glColor3f(0, 0, 1);
	for (int i = 0; i < linevec.size(); i++) {
		if (F_flag == true || B_flag == true || C_flag == true) {
			string x = "(";
			x.append(to_string(linevec[i].startX));
			x.append(",");
			x.append(to_string(linevec[i].startY));
			x.append(")->(");
			x.append(to_string(linevec[i].endX));
			x.append(",");
			x.append(to_string(linevec[i].endY));
			x.append(")");
			if (i == 0) {
				x = "(";
				x.append(to_string(linevec[i].endX)); x.append(","); x.append(to_string(linevec[i].endY)); x.append(")->("); x.append(to_string(linevec[i].startX)); 	x.append(","); x.append(to_string(linevec[i].startY));
				x.append(")");
			}
			//cout << linevec[i].startX << "," << linevec[i].startY << "," << linevec[i].endX << "," << linevec[i].endY << endl;
			renderBitmapCharacher(1030, 885 - i * 15, 0, (void *)font, x.c_str());
		}
	}
	renderBitmapCharacher(1025, 345-15, 0, (void *)font, "___________________________");
	renderBitmapCharacher(1030, 330-15, 0, (void *)font, "Command ");
	renderBitmapCharacher(1030, 310-15, 0, (void *)font, "E - Elevator Algorithm");
	renderBitmapCharacher(1030, 290-15, 0, (void *)font, "F - 1 robot FIFO: ");
	renderBitmapCharacher(1030, 270.0-15, 0, (void *)font, "C - 1 robot CovexHull: ");
	renderBitmapCharacher(1030, 250.0-15, 0, (void *)font, "B - 1 robot Greedy: ");
	renderBitmapCharacher(1030, 230.0-15, 0, (void *)font, "Q - 4 robot ");
	renderBitmapCharacher(1030, 210-15, 0, (void *)font, "    Position Greedy : ");
	renderBitmapCharacher(1030, 190-15, 0, (void *)font, "D - 4 robot random Greedy: ");
	renderBitmapCharacher(1030, 170-15, 0, (void *)font, "O - 4 robot Col Greedy: ");
	renderBitmapCharacher(1030, 150-15, 0, (void *)font, "P - 4 robot Row Greedy: ");

	renderBitmapCharacher(1030, 130-15, 0, (void *)font, "Z - 4 robot ");
	renderBitmapCharacher(1030, 115-15, 0, (void *)font, "    Position Convex : ");
	renderBitmapCharacher(1030, 95-15, 0, (void *)font, "X - 4 robot Row Convex: ");
	renderBitmapCharacher(1030, 75-15, 0, (void *)font, "N - 4 robot Col Convex: ");
	renderBitmapCharacher(1030, 55-15, 0, (void *)font, "M - 4 robot RaNDOM Convex: ");

	if(command_color ==0){
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 310 - 15, 0, (void *)font, "E - Elevator Algorithm");
		glColor3f(0, 0, 1);
	}

	if (command_color == 1) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 290-15, 0, (void *)font, "F - 1 robot FIFO: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 2) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 270.0-15, 0, (void *)font, "C - 1 robot CovexHull: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 3) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 250.0-15, 0, (void *)font, "B - 1 robot Greedy: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 4) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 230.0-15, 0, (void *)font, "Q - 4 robot ");
		renderBitmapCharacher(1030, 210-15, 0, (void *)font, "    Position Greedy : ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 5) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 190-15, 0, (void *)font, "D - 4 robot random Greedy: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 6) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 170-15, 0, (void *)font, "O - 4 robot Col Greedy: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 7) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 150-15, 0, (void *)font, "P - 4 robot Row Greedy: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 8) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 130-15, 0, (void *)font, "Z - 4 robot ");
		renderBitmapCharacher(1030, 115-15, 0, (void *)font, "    Position Convex : ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 9) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 95-15, 0, (void *)font, "X - 4 robot Row Convex: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 10) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 75-15, 0, (void *)font, "N - 4 robot Col Convex: ");
		glColor3f(0, 0, 1);
	}
	else if (command_color == 11) {
		glColor3f(1, 0, 0);
		renderBitmapCharacher(1030, 55-15, 0, (void *)font, "M - 4 robot RaNDOM Convex: ");
		glColor3f(0, 0, 1);
	}



	renderBitmapCharacher(045, 980, 0, (void *)font, "1");
	renderBitmapCharacher(270, 980, 0, (void *)font, "10");
	renderBitmapCharacher(520, 980, 0, (void *)font, "20");
	renderBitmapCharacher(770, 980, 0, (void *)font, "30");

	renderBitmapCharacher(8, 245, 0, (void *)font, "30");
	renderBitmapCharacher(8, 495, 0, (void *)font, "20");
	renderBitmapCharacher(8, 745, 0, (void *)font, "10");

	glColor3f(1, 0, 0);
	if (F_flag || B_flag || C_flag) {
		renderBitmapCharacher(1170, 885 - capture_counter * 15 +15, 0, (void *)font, "V");
	}//glPopMatrix();
	//glutPostRedisplay();
	glPopMatrix();

	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	int gcounter = 1;
	int scounter = 1;
	
	for (int x = 25; x < ww - 300 + 25; x += termW) // ���� �׸���
	{
		glLineWidth(1);
		glColor3f(0, 0, 1);
		if (gcounter % 10 == 0) {
			glLineWidth(2); glColor3f(0.5, 0, 0);
			glBegin(GL_LINES);
			glVertex2f(x + termW, termH);
			glVertex2f(x + termW, wh - termH);
			glEnd();
		}
		gcounter++;
		for (int y = 25; y <= wh; y += termH) {
			glLineWidth(1);
			glColor3f(0, 0, 1);
			if (scounter % 10 == 9) {
				glLineWidth(2); glColor3f(0.5, 0, 0);
				glBegin(GL_LINES);
				glVertex2f(termW, y + termH);
				glVertex2f(ww - 300 - termW + 50, y + termH);
				glEnd();
				
			}
			scounter++;
		}
	}
	
	int f_counter = 0;
	


	glColor3f(1, 1, 1);
	/*
	radius = 20;
	for (int i = 0; i < 360; i++)	{
			glBegin(GL_TRIANGLE_FAN);
			float degInRad = i * DEG2RAD;
			glVertex2f(cos(degInRad)*radius + (1 * termW), sin(degInRad)*radius + (20 * termH));

		}
	glEnd();
	*/
	radius = 5;

	for (int y = 0; y < 100; y++)
	{
		for (int x = 0; x < 100; x++)
		{
			if (map[x][y] == NON)
				continue;
			if (map[x][y] == WhiteStone)
				glColor3f(1, 1, 1);
			if (map[x][y] == BlackStone)
				glColor3f(0, 0, 0);
			if (map[x][y] == MidStone)
				glColor3f(255, 255, 0);
			if (map[x][y] == Door)
				glColor3f(0.9, 0.7, 0.3);
			if (map[x][y] == Robot) {
				glColor3f(0.2, 0.4, 0.3);
			}

			//glPushMatrix();
			if (map[x][y] != Door) {
				glBegin(GL_TRIANGLE_FAN);
				
				for (int i = 0; i < 360; i++)
				{
					float degInRad = i * DEG2RAD;
					glVertex2f(cos(degInRad)*radius + (x * termW), sin(degInRad)*radius + (y * termH));

				}
				glEnd();
			}
	

			
			
			//char t10[100] = 
			//string xa = to_string(i);
			//renderBitmapCharacher(cos(1)*radius + (linevec[i].endX * termW) - 12, sin(0)*radius + (linevec[i].endY * termH) - 5, 0, (void *)font, xa.c_str());

			//glPopMatrix();
		}

	}
	if (half_flag == true) { capture_counter = linevec.size(); 
	for (int i = 0; i < capture_counter % (linevec.size()+1); i++) {

		string xa = to_string(i);
		int temp_x, temp_y;

		temp_x = linevec[i].endX;
		temp_x = temp_x * 25 + 25;
		temp_y = linevec[i].endY;
		temp_y = temp_y * 25;
		temp_y = wh - temp_y;
		glColor3f(0, 0, 0);
		// (linevec[i].endY != 20 && linevec[i].endY != 0) {
		renderBitmapCharacher(temp_x + 3, temp_y + 12, 0, (void*)font2, xa.c_str());



		//renderBitmapCharacher(cos(1)*radius + (linevec[i].endX * termW) - 12, sin(0)*radius + (linevec[i].endY * termH) - 5, 0, (void *)font, xa.c_str());
	}
	}

	if (linevec.size() != 0) {
		int t = 0;
		for (int i = 0; i < capture_counter % linevec.size(); i++) {

		
			string xa = to_string(t);
			int temp_x, temp_y;

			temp_x = linevec[i].endX;
			temp_x = temp_x * 25 + 25;
			temp_y = linevec[i].endY;
			temp_y = temp_y * 25;
			temp_y = wh - temp_y;
			glColor3f(0, 0, 0);
			if (linevec[i].endY != 20 && linevec[i].endY != 0) {
				renderBitmapCharacher(temp_x + 3, temp_y + 12, 0, (void*)font2, xa.c_str());
				t++;
			}
			else {
				
			}
			
			//renderBitmapCharacher(cos(1)*radius + (linevec[i].endX * termW) - 12, sin(0)*radius + (linevec[i].endY * termH) - 5, 0, (void *)font, xa.c_str());
		}
		
	}
	f_counter = 0;

	glColor3f(1, 0, 0);
	liner temp_liner;
	if (qcounter == 0)	glColor3f(1, 0, 0);
	else if (qcounter == 1) glColor3f(0.5, 0.5, 1);
	else if (qcounter == 2) glColor3f(0, 0, 1);
	else glColor3f(0.5, 0.5, 0.3);
	glLineWidth(3);

	for (int y = 0; y < 100; y++)
	{
		for (int x = 0; x < 100; x++)
		{

			if (line[x][y] == NON)
				continue;
			if (line[x][y] == LineStart) {
				temp_liner.startX = x * 10;
				temp_liner.startY = y * 10;
				//glVertex2f(x * 10, y * 10);
				line[x][y] = 0;
			}
			if (line[x][y] == LineEnd) {
				//glVertex2f(x * 10, y * 10);
				temp_liner.endX = x * 10;
				temp_liner.endY = y * 10;
				line[x][y] = 0;
			}
		}
	}
	//linevec.push_back(temp_liner);


	
	if (linevec.size() != 0) {
		for (int i = 0; i < capture_counter; i++) {

			if (i != (capture_counter - 1)) {
				glColor3f(1, 0, 0);

			}
			else {
				glColor3f(0.5, 1, 0);
			}
			glBegin(GL_LINES);
			glPushMatrix();
			linevec[i].startX = linevec[i].startX * 25 + 25, linevec[i].startY = linevec[i].startY * 25;
			linevec[i].endX = linevec[i].endX * 25 + 25, linevec[i].endY = linevec[i].endY * 25;
			linevec[i].startY = wh - linevec[i].startY;
			linevec[i].endY = wh - linevec[i].endY;
			//x1 = x1 * 10; y1 = y1 * 10;
			//x2 = x2 * 10; y2 = y2 * 10;
			//y1 = wh - y1;
			//y2 = wh - y2;
			glVertex2f(linevec[i].startX, linevec[i].startY);
			glVertex2f(linevec[i].endX, linevec[i].startY);

			glVertex2f(linevec[i].endX, linevec[i].startY);
			glVertex2f(linevec[i].endX, linevec[i].endY);

			string xa = to_string(i);
			//renderBitmapCharacher(cos(1)*radius + (linevec[i].endX * termW) - 12, sin(0)*radius + (linevec[i].endY * termH) - 5, 0, (void *)font, xa.c_str());
			glColor3f(0, 0.1, 1);
			renderBitmapCharacher(linevec[i].endX, linevec[i].endY, 0, (void *)font, xa.c_str());
			glColor3f(1, 0, 0);
			//glutPostRedisplay();
			//glutPostRedisplay();
			//Sleep(1000);

		}
	}
	glEnd();
	glFlush();
	//glPopMatrix();



	glutSwapBuffers();
	display_counter++;
}

void t5(string msg) {
	//glutInit();
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(1300, 1000);
	glutInitWindowPosition(600, 0);
	glutCreateWindow(msg.c_str());

	myinit();
	glutReshapeFunc(myReshape);
	//glutMouseFunc(mouse);
	//glutKeyboardFunc(mykey);
	glutKeyboardFunc(DoKeyboard);
	glutDisplayFunc(display);
	glutMainLoop();
	//if (caculate_finish == true) {
	//   Sleep(5000);
	//   glutDestroyWindow(3);
	// }
}


bool comp_dist_func(work_vector x, work_vector y) {
	return x.mov < y.mov;
} // �����ϱ� ���� ����� �а�. ������ ���ַ� ����.
bool comp_ctime_func(work_vector x, work_vector y) {
	return x.create_time < y.create_time;
}


void task_sorting(string msg) {
	work_vector comp_to_dist;

	for (int i = work_size; i < work_list.size(); i++) { // ó�� �̵��� �ð� ���� �߻��� �ϵ��� �����ϴ� ����.

		if (work_list[i].request == 0) {
			req_0_dist = abs(work_list[i].x - a.robot[0].x) + abs(work_list[i].y - a.robot[0].y);
			// work_list�� 0����, ���� �κ��� �Ÿ��� ���
			comp_to_dist.x = work_list[i].x;
			comp_to_dist.y = work_list[i].y;
			comp_to_dist.end_x = work_list[i].end_x;
			comp_to_dist.end_y = work_list[i].end_y;
			comp_to_dist.create_time = work_list[i].create_time;
			// �̵� �ؾ� �� ���� ����
			comp_to_dist.mov = req_0_dist;
			// mov�� ���� �̵��ؾ� �ϴ� ���� �̵� �Ÿ��̱� ������ ���� �� ��.
			comp_to_dist.request = 0;
			// ��û �� ����
			comp_vec.push_back(comp_to_dist);
			copy_vector.push_back(comp_to_dist);
			ele_vector.push_back(comp_to_dist);

			if ((comp_to_dist.x < 20) && (comp_to_dist.y < 20)) { // 20�̸�
				copy_divider[0].push_back(comp_to_dist);
			}
			else if ((comp_to_dist.x < 20) && (comp_to_dist.y > 20)) { //x20����, y20�̻�
				copy_divider[1].push_back(comp_to_dist);
			}
			else if ((comp_to_dist.x > 20) && (comp_to_dist.y > 20)) { //�Ѵ� 20�̻�
				copy_divider[2].push_back(comp_to_dist);
			}
			else { //x20�̻�, y20����
				copy_divider[3].push_back(comp_to_dist);
			}

			if (comp_to_dist.x < 10) {
				row[0].push_back(comp_to_dist);
			}
			else if (comp_to_dist.x < 20) {
				row[1].push_back(comp_to_dist);
			}
			else if (comp_to_dist.x < 30) {
				row[2].push_back(comp_to_dist);
			}
			else {
				row[3].push_back(comp_to_dist);
			}
			if (comp_to_dist.y < 10) {
				col[0].push_back(comp_to_dist);
			}
			else if (comp_to_dist.y < 20) {
				col[1].push_back(comp_to_dist);
			}
			else if (comp_to_dist.y < 30) {
				col[2].push_back(comp_to_dist);
			}
			else {
				col[3].push_back(comp_to_dist);
			}

			convex_vector.push_back(comp_to_dist);
		}
		// else if �� ���� ������ ����. (���⼭�� �Ÿ� ��� ���� ª�� �Ÿ��� �����ؼ� 0���� �δ°��� �߿�.)
		else if (work_list[i].request == 1) {
			req_1_dist = abs(work_list[i].x - a.robot[0].x) + abs(work_list[i].y - a.robot[0].y);
			comp_to_dist.x = work_list[i].x;
			comp_to_dist.y = work_list[i].y;
			comp_to_dist.end_x = work_list[i].end_x;
			comp_to_dist.end_y = work_list[i].end_y;
			comp_to_dist.create_time = work_list[i].create_time;
			comp_to_dist.mov = req_1_dist;
			comp_to_dist.request = 1;
			comp_vec.push_back(comp_to_dist);
			copy_vector.push_back(comp_to_dist);
			ele_vector.push_back(comp_to_dist);
			convex_vector.push_back(comp_to_dist);
			if ((comp_to_dist.end_x < 20) && (comp_to_dist.end_y < 20)) { // 20�̸�
				copy_divider[0].push_back(comp_to_dist);
			}
			else if ((comp_to_dist.end_x < 20) && (comp_to_dist.end_y > 20)) { //x20����, y20�̻�
				copy_divider[1].push_back(comp_to_dist);
			}
			else if ((comp_to_dist.end_x > 20) && (comp_to_dist.end_y > 20)) { //�Ѵ� 20�̻�
				copy_divider[2].push_back(comp_to_dist);
			}
			else { //x20�̻�, y20����
				copy_divider[3].push_back(comp_to_dist);
			}
			if (comp_to_dist.end_x < 10) {
				row[0].push_back(comp_to_dist);
			}
			else if (comp_to_dist.end_x < 20) {
				row[1].push_back(comp_to_dist);
			}
			else if (comp_to_dist.end_x < 30) {
				row[2].push_back(comp_to_dist);
			}
			else {
				row[3].push_back(comp_to_dist);
			}
			if (comp_to_dist.end_y < 10) {
				col[0].push_back(comp_to_dist);
			}
			else if (comp_to_dist.end_y < 20) {
				col[1].push_back(comp_to_dist);
			}
			else if (comp_to_dist.end_y < 30) {
				col[2].push_back(comp_to_dist);
			}
			else {
				col[3].push_back(comp_to_dist);
			}

		}
		else if (work_list[i].request == 2) {
			req_2_dist = abs(work_list[i].x - a.robot[0].x) + abs(work_list[i].y - a.robot[0].y);
			comp_to_dist.x = work_list[i].x;
			comp_to_dist.y = work_list[i].y;
			comp_to_dist.end_x = work_list[i].end_x;
			comp_to_dist.end_y = work_list[i].end_y;
			comp_to_dist.create_time = work_list[i].create_time;
			comp_to_dist.mov = req_2_dist;
			comp_to_dist.request = 2;
			comp_vec.push_back(comp_to_dist);
			copy_vector.push_back(comp_to_dist);
			convex_vector.push_back(comp_to_dist);
			ele_vector.push_back(comp_to_dist);

			if ((comp_to_dist.x < 20) && (comp_to_dist.y < 20)) { // 20�̸�
				copy_divider[0].push_back(comp_to_dist);
			}
			else if ((comp_to_dist.x < 20) && (comp_to_dist.y > 20)) { //x20����, y20�̻�
				copy_divider[1].push_back(comp_to_dist);
			}
			else if ((comp_to_dist.x > 20) && (comp_to_dist.y > 20)) { //�Ѵ� 20�̻�
				copy_divider[2].push_back(comp_to_dist);
			}
			else { //x20�̻�, y20����
				copy_divider[3].push_back(comp_to_dist);
			}
			if (comp_to_dist.x < 10) {
				row[0].push_back(comp_to_dist);
			}
			else if (comp_to_dist.x < 20) {
				row[1].push_back(comp_to_dist);
			}
			else if (comp_to_dist.x < 30) {
				row[2].push_back(comp_to_dist);
			}
			else {
				row[3].push_back(comp_to_dist);
			}
			if (comp_to_dist.y < 10) {
				col[0].push_back(comp_to_dist);
			}
			else if (comp_to_dist.y < 20) {
				col[1].push_back(comp_to_dist);
			}
			else if (comp_to_dist.y < 30) {
				col[2].push_back(comp_to_dist);
			}
			else {
				col[3].push_back(comp_to_dist);
			}
		}
		sort(comp_vec.begin(), comp_vec.end(), comp_ctime_func);
		sort(copy_vector.begin(), copy_vector.end(), comp_ctime_func);
		sort(convex_vector.begin(), convex_vector.end(), comp_ctime_func);
		sort(ele_vector.begin(), ele_vector.end(), comp_ctime_func);
		if (i % 4 == 0) {
			copy_random_divider[0].push_back(comp_to_dist);
		}
		else if (i % 4 == 1) {
			copy_random_divider[1].push_back(comp_to_dist);
		}
		else if (i % 4 == 2) {
			copy_random_divider[2].push_back(comp_to_dist);
		}
		else {
			copy_random_divider[3].push_back(comp_to_dist);
		}


	}


	work_size++; // ���� ��ģ �� work_list �� size�� ������Ų��.
}


bool fin = false;
bool greedy_fin = false;
bool convex_fin = false;

int fifo_freight_count = 0;

void fifo2() {
	work_vector comp_to_dist;
	if (fin == true) return;
	float first_move_time, first_move_dist;
	first_move_time = (abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y)) / 10.0;
	first_move_dist = abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y);

	if (comp_vec.size() == 1) {
		a.robot[0].x = comp_vec[0].x;
		a.robot[0].y = comp_vec[0].y;
		comp_to_dist.x = comp_vec[0].x;
		comp_to_dist.y = comp_vec[0].y;
		comp_to_dist.end_x = comp_vec[0].end_x;
		comp_to_dist.end_y = comp_vec[0].end_y;
		comp_to_dist.request = comp_vec[0].request;
		drow_vec.push_back(comp_to_dist);
	}
	else {

		if (work_counter == 0) {
			comp_to_dist.x = a.robot[0].x;
			comp_to_dist.y = a.robot[0].y;
			comp_to_dist.end_x = a.door[0].x;
			comp_to_dist.end_y = a.door[0].y;
			comp_to_dist.request = -1;
			a.robot[0].x = a.door[0].x;
			a.robot[0].y = a.door[0].y;
			full_work_dist.push_back(first_move_dist);
			full_work_time.push_back(first_move_time);
			drow_vec.push_back(comp_to_dist);
			work_counter++;
			fifo2();
		} // ������ �̵��ϰ� greedy �Լ��� ���ư� counter ����.

		else if (work_counter == 1) {
			sort(comp_vec.begin(), comp_vec.end(), comp_ctime_func);
			// ���� �ð��� ���� ����
			comp_to_dist.x = comp_vec[0].x;
			comp_to_dist.y = comp_vec[0].y;
			comp_to_dist.end_x = comp_vec[0].end_x;
			comp_to_dist.end_y = comp_vec[0].end_y;
			a.robot[0].x = comp_vec[0].x;
			a.robot[0].y = comp_vec[0].y;
			comp_to_dist.request = comp_vec[0].request;
			drow_vec.push_back(comp_to_dist);
			comp_vec.erase(comp_vec.begin());
			fifo_freight_count++;
			work_counter++;
			fifo2();
		}

		// ȭ�� ī��Ʈ�� 5�϶��� ������ �������� fifo ����
		else if (work_counter != 0 && comp_vec.size() != 1) {
			sort(comp_vec.begin(), comp_vec.end(), comp_ctime_func);
			// ���� �ð��� ���� ����
			
			if (comp_vec[0].request == 0) {
				if (fifo_freight_count == 5) {
					comp_to_dist.x = a.robot[0].x;
					comp_to_dist.y = a.robot[0].y;
					comp_to_dist.end_x = a.door[0].x;
					comp_to_dist.end_y = a.door[0].y;
					comp_to_dist.request = -1;
					drow_vec.push_back(comp_to_dist);
					a.robot[0].x = a.door[0].x;
					a.robot[0].y = a.door[0].y;
					fifo_freight_count = 0;
					fifo2();
				}
				else {
					comp_to_dist.x = comp_vec[0].x;
					comp_to_dist.y = comp_vec[0].y;
					comp_to_dist.end_x = comp_vec[0].end_x;
					comp_to_dist.end_y = comp_vec[0].end_y;
					a.robot[0].x = comp_vec[0].x;
					a.robot[0].y = comp_vec[0].y;
					comp_to_dist.request = comp_vec[0].request;
					drow_vec.push_back(comp_to_dist);
					comp_vec.erase(comp_vec.begin());
					fifo_freight_count++;
					work_counter++;
					fifo2();
				}
			}
			else {
				if (fifo_freight_count == 5) {
					comp_to_dist.x = a.robot[0].x;
					comp_to_dist.y = a.robot[0].y;
					comp_to_dist.end_x = a.door[0].x;
					comp_to_dist.end_y = a.door[0].y;
					comp_to_dist.request = -1;
					drow_vec.push_back(comp_to_dist);
					a.robot[0].x = a.door[0].x;
					a.robot[0].y = a.door[0].y;
					fifo_freight_count = 0;
					fifo2();
				}
				else {
					comp_to_dist.x = comp_vec[0].x;
					comp_to_dist.y = comp_vec[0].y;
					comp_to_dist.end_x = comp_vec[0].end_x;
					comp_to_dist.end_y = comp_vec[0].end_y;
					a.robot[0].x = comp_vec[0].x;
					a.robot[0].y = comp_vec[0].y;
					comp_to_dist.request = comp_vec[0].request;
					drow_vec.push_back(comp_to_dist);
					comp_vec.erase(comp_vec.begin());
					fifo_freight_count++;
					work_counter++;
					fifo2();
				}
			}
		}
	}
}

int greedy_freight_count = 0;
void greedy() {
	/*comp_vec �� ���� ���ο� ������ �ʿ���. work_list �� �̵� �Ÿ��� ���ؼ� sorting �Ǿ�����.*/
	work_vector comp_to_dist;
	float temp_gt = 0, temp_gd = 0;
	int temp_req = 0;
	// ���� ���� work_list ���� comp_vec�� ��� �� �ִ�.
	if (greedy_fin == true)return;
	//sort(copy_vector.begin(), copy_vector.end(), comp_ctime_func); // �� ó�� ���� �ð��� ���� ������ �ʿ�.

	float first_move_time, first_move_dist;
	if (qcounter == 0) {
		first_move_time = (abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y)) / 10.0;
		first_move_dist = abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y);
	}
	else if (qcounter == 1) {
		first_move_dist = abs(second_robot_x - a.door[0].x) + abs(second_robot_y - a.door[0].y);
		first_move_time = first_move_dist / 10.0;
	}
	else if (qcounter == 2) {
		first_move_dist = abs(third_robot_x - a.door[0].x) + abs(third_robot_y - a.door[0].y);
		first_move_time = first_move_dist / 10.0;
	}
	else if (qcounter == 3) {
		first_move_dist = abs(forth_robot_x - a.door[0].x) + abs(forth_robot_y - a.door[0].y);
		first_move_time = first_move_dist / 10.0;
	}

	//if (copy_vector.size() == 1) return;

	if (copy_vector.size() == 1 ) {
		all_sort_flag = true;
		a.robot[0].x = copy_vector[0].x;
		a.robot[0].y = copy_vector[0].y;
		comp_to_dist.x = copy_vector[0].x;
		comp_to_dist.y = copy_vector[0].y;
		comp_to_dist.end_x = copy_vector[0].end_x;
		comp_to_dist.end_y = copy_vector[0].end_y;
		comp_to_dist.request = copy_vector[0].request;
		greedy_drow_vec.push_back(comp_to_dist);
	}

	if (greedy_counter == 0) {
		comp_to_dist.x = a.robot[0].x;
		comp_to_dist.y = a.robot[0].y;
		comp_to_dist.end_x = a.door[0].x;
		comp_to_dist.end_y = a.door[0].y;
		comp_to_dist.request = -1;
		a.robot[0].x = a.door[0].x;
		a.robot[0].y = a.door[0].y;
		greedy_full_dist.push_back(first_move_dist);
		greedy_full_time.push_back(first_move_time);
		greedy_drow_vec.push_back(comp_to_dist);
		greedy_counter++;
		greedy();
	} // ������ �̵��ϰ� greedy �Լ��� ���ư� counter ����.

	else if (greedy_counter != 0 && copy_vector.size() != 1) { // ù ��° �� ���.
		
		if ((all_sort_flag == false) && (greedy_full_time[greedy_counter - 1] > copy_vector[greedy_idx].create_time)) {
			greedy_idx++;
			greedy();
		}
		// greedy_counter 0���� ó���� ������ �̵� �Ÿ�  , �׸��� greedy index�� ã�Ƴ���. 
		// ���� greedy�� �������� else������ ����.
		// ���� greedy_counter�� �����ȴ�.

		else {

			if (greedy_counter == 1) {// �������� �̵� �Ÿ��� ���� ���.

				if (greedy_idx == 0) {

					// greedy_idx== 0  �� ���� ���� ���� �� ���� �ϳ��� �ϸ� �� ���           
					temp_gd = abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y);
					temp_gt = (abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y)) / 10.0;

					comp_to_dist.x = copy_vector[0].x;
					comp_to_dist.y = copy_vector[0].y;
					comp_to_dist.end_x = copy_vector[0].end_x;
					comp_to_dist.end_y = copy_vector[0].end_y;

					a.robot[qcounter].x = copy_vector[0].x;
					a.robot[qcounter].y = copy_vector[0].y; // ������ �κ��� �̵�.

					comp_to_dist.mov = temp_gd;

					comp_to_dist.request = copy_vector[0].request;

					comp_to_dist.end_time = temp_gt + copy_vector[0].create_time;

					matrix[a.robot[qcounter].x][a.robot[qcounter].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

					greedy_full_dist.push_back(temp_gd);
					greedy_full_time.push_back(temp_gt);

					greedy_drow_vec.push_back(comp_to_dist);
					// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
					// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
					copy_vector.erase(copy_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
					greedy_freight_count++;
					greedy_counter++; // ���� �ϰ� �� ������ ����.
					greedy(); // -> �ٽ� greedy�� ���;��Ѵ�.
				}

				else {
					if (greedy_counter != 0) {
						for (int i = 0; i < greedy_idx; i++) { // greedy counter ������ �ϸ� ���� 
							sort(copy_vector.begin(), copy_vector.begin() + greedy_idx, comp_dist_func);
						} // ���̿� �ִ� ���� �ٽ� ������ 0��° �ϸ� �ֱ�.
						  //sort(copy_vector.begin(), copy_vector.begin() + greedy_idx, comp_dist_func);
						if (greedy_freight_count == 5) {
							comp_to_dist.x = a.robot[0].x;
							comp_to_dist.y = a.robot[0].y;
							comp_to_dist.end_x = a.door[0].x;
							comp_to_dist.end_y = a.door[0].y;
							comp_to_dist.request = -1;
							a.robot[0].x = a.door[0].x;
							a.robot[0].y = a.door[0].y;
							greedy_drow_vec.push_back(comp_to_dist);
							greedy_freight_count = 0;
							greedy();
						}
						else {
							temp_gd = abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y);
							temp_gt = (abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y)) / 10.0;

							comp_to_dist.x = copy_vector[0].x;
							comp_to_dist.y = copy_vector[0].y;
							comp_to_dist.end_x = copy_vector[0].end_x;
							comp_to_dist.end_y = copy_vector[0].end_y;
							comp_to_dist.request = copy_vector[0].request;

							a.robot[qcounter].x = copy_vector[0].x;
							a.robot[qcounter].y = copy_vector[0].y; // ������ �κ��� �̵�.

							matrix[a.robot[qcounter].x][a.robot[qcounter].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����


							comp_to_dist.end_time = temp_gt + copy_vector[0].create_time;

							greedy_full_dist.push_back(temp_gd);
							greedy_full_time.push_back(temp_gt);

							greedy_drow_vec.push_back(comp_to_dist);
							// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
							// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
							copy_vector.erase(copy_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
							greedy_counter++; // ���� �ϰ� �� ������ ����.
							greedy_freight_count++;
							greedy(); // -> �ٽ� greedy�� ���;��Ѵ�.
						}	
					}
					else {
						sort(copy_vector.begin(), copy_vector.end(), comp_dist_func);
						// ���� �ϰ� ������ ,�̵��Ÿ��� ���� ª�� �Ͽ� ���Ͽ� ����.
						if (greedy_freight_count == 5) {
							comp_to_dist.x = a.robot[0].x;
							comp_to_dist.y = a.robot[0].y;
							comp_to_dist.end_x = a.door[0].x;
							comp_to_dist.end_y = a.door[0].y;
							comp_to_dist.request = -1;
							a.robot[0].x = a.door[0].x;
							a.robot[0].y = a.door[0].y;
							greedy_drow_vec.push_back(comp_to_dist);
							greedy_freight_count = 0;
							greedy();
						}
						else {
							temp_gd = abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y);
							temp_gt = (abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y)) / 10.0;

							comp_to_dist.x = copy_vector[0].x;
							comp_to_dist.y = copy_vector[0].y;
							comp_to_dist.end_x = copy_vector[0].end_x;
							comp_to_dist.end_y = copy_vector[0].end_y;
							comp_to_dist.request = copy_vector[0].request;

							a.robot[qcounter].x = copy_vector[0].x;
							a.robot[qcounter].y = copy_vector[0].y; // ������ �κ��� �̵�.

							matrix[a.robot[qcounter].x][a.robot[qcounter].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

							matrix[a.robot[qcounter].x][a.robot[qcounter].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

							greedy_full_dist.push_back(temp_gd);
							greedy_full_time.push_back(temp_gt);

							greedy_drow_vec.push_back(comp_to_dist);
							// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
							// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
							copy_vector.erase(copy_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
							greedy_counter++; // ���� �ϰ� �� ������ ����.
							greedy_freight_count++;
							greedy(); // -> �ٽ� greedy�� ���;��Ѵ�.
						}
					}
				}
			}
			else {
				if (all_sort_flag == false && greedy_full_time[greedy_counter - 1] > copy_vector[greedy_idx].create_time) {
					greedy_idx++;
					greedy();
				}
				else {
					if (greedy_freight_count == 5) {
						comp_to_dist.x = a.robot[0].x;
						comp_to_dist.y = a.robot[0].y;
						comp_to_dist.end_x = a.door[0].x;
						comp_to_dist.end_y = a.door[0].y;
						comp_to_dist.request = -1;
						a.robot[0].x = a.door[0].x;
						a.robot[0].y = a.door[0].y;
						greedy_drow_vec.push_back(comp_to_dist);
						greedy_freight_count = 0;
						greedy();
					}
					else {
						sort(copy_vector.begin(), copy_vector.end(), comp_dist_func);
						// ���� �ϰ� ������ ,�̵��Ÿ��� ���� ª�� �Ͽ� ���Ͽ� ����.   
						temp_gd = abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y);
						temp_gt = (abs(a.robot[qcounter].x - copy_vector[0].x) + abs(a.robot[qcounter].y - copy_vector[0].y)) / 10.0;

						comp_to_dist.x = copy_vector[0].x;
						comp_to_dist.y = copy_vector[0].y;
						comp_to_dist.end_x = copy_vector[0].end_x;
						comp_to_dist.end_y = copy_vector[0].end_y;
						comp_to_dist.request = copy_vector[0].request;

						a.robot[qcounter].x = copy_vector[0].x;
						a.robot[qcounter].y = copy_vector[0].y; // ������ �κ��� �̵�.

						matrix[a.robot[qcounter].x][a.robot[qcounter].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

						greedy_full_dist.push_back(temp_gd);
						greedy_full_time.push_back(temp_gt);

						greedy_drow_vec.push_back(comp_to_dist);
						// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
						// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
						copy_vector.erase(copy_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
						greedy_counter++; // ���� �ϰ� �� ������ ����.
						greedy_freight_count++;
						greedy(); // -> �ٽ� greedy�� ���;��Ѵ�.
					}
					
				}
			}
		}
	}
}

bool convex_all_sort = false;
bool x_comp_operation(work_vector work1, work_vector work2) {
	return work1.x > work2.x;
}
bool y_comp_operation(work_vector work1, work_vector work2) {
	return work1.y > work2.y;
}
bool cross_product(int x, int y, work_vector work) {
	return x * work.y - y * work.x > 0 ? 1 : 2;
}
int convex_freight_count = 0;
void convex_hull() {
	work_vector comp_to_dist;
	if (convex_fin == true) return;
	float temp_gt = 0, temp_gd = 0;
	int temp_req = 0;
	int temp_cross = 0;
	// ���� ���� work_list ���� comp_vec�� ��� �� �ִ�.
	bool wait_flag = false;
	//sort(copy_vector.begin(), copy_vector.end(), comp_ctime_func); // �� ó�� ���� �ð��� ���� ������ �ʿ�.

	float convex_first_move_time = (abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y)) / 10.0;
	float convex_first_move_dist = abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y);
	if (convex_counter > convex_size) return;

	if (convex_idx + 1 >= convex_vector.size()) {
		convex_all_sort = true; // ���⼭�� ccw�� ���� ��� ���� ���� �ؾ���.
	}

	if (convex_counter == 0) {
		comp_to_dist.x = a.robot[0].x;
		comp_to_dist.y = a.robot[0].y;
		comp_to_dist.end_x = a.door[0].x;
		comp_to_dist.end_y = a.door[0].y;
		comp_to_dist.request = -1;
		a.robot[0].x = a.door[0].x;
		a.robot[0].y = a.door[0].y;
		convex_full_dist.push_back(convex_first_move_dist);
		convex_full_time.push_back(convex_first_move_time);
		convex_drow_vec.push_back(comp_to_dist);
		convex_counter++;
		convex_hull();
	} // ������ �̵��ϰ� convex �Լ��� ���ư� counter ����.

	else if (convex_counter != 0 && convex_counter < convex_size) { // ù ��° �� ���.

		if ((convex_all_sort == false) && (convex_full_time[convex_counter - 1] > convex_vector[convex_idx].create_time)) {
			convex_idx++;
			convex_hull();
		}// ù �۾��� �����ϰ� ���� 2�� �̻� �������� Ȯ���� �ؾ���.

		else {

			if (convex_counter == 1) {

				if (convex_idx == 0) {// �߰� �� ���� �� �ϳ�
					temp_gd = abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y);
					temp_gt = (abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y)) / 10.0;

					comp_to_dist.x = convex_vector[0].x;
					comp_to_dist.y = convex_vector[0].y;
					comp_to_dist.end_x = convex_vector[0].end_x;
					comp_to_dist.end_y = convex_vector[0].end_y;

					a.robot[0].x = convex_vector[0].x;
					a.robot[0].y = convex_vector[0].y; // ������ �κ��� �̵�.

					comp_to_dist.mov = temp_gd;

					comp_to_dist.request = convex_vector[0].request;

					comp_to_dist.end_time = temp_gt + convex_vector[0].create_time;

					matrix[a.robot[0].x][a.robot[0].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

					convex_full_dist.push_back(temp_gd);
					convex_full_time.push_back(temp_gt);

					convex_drow_vec.push_back(comp_to_dist);
					// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
					// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
					// Jarvis march ����� �̿��ؾ���.
					convex_vector.erase(convex_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
					convex_counter++; // ���� �ϰ� �� ������ ����.
					convex_freight_count++;
					convex_hull(); // -> �ٽ� convex_hull�� ���;��Ѵ�.
				}
				else {
					// �߰��� ���� ������ ���� ������, x���� ū������ �̵� �ʿ�.
					sort(convex_vector.begin(), convex_vector.begin() + convex_idx, x_comp_operation);
					temp_gd = abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y);
					temp_gt = (abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y)) / 10.0;

					comp_to_dist.x = convex_vector[0].x;
					comp_to_dist.y = convex_vector[0].y;
					comp_to_dist.end_x = convex_vector[0].end_x;
					comp_to_dist.end_y = convex_vector[0].end_y;

					a.robot[0].x = convex_vector[0].x;
					a.robot[0].y = convex_vector[0].y; // ������ �κ��� �̵�.

					comp_to_dist.mov = temp_gd;

					comp_to_dist.request = convex_vector[0].request;

					comp_to_dist.end_time = temp_gt + convex_vector[0].create_time;

					matrix[a.robot[0].x][a.robot[0].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

					convex_full_dist.push_back(temp_gd);
					convex_full_time.push_back(temp_gt);

					convex_drow_vec.push_back(comp_to_dist);
					// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
					// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
					// Jarvis march ����� �̿��ؾ���.
					convex_vector.erase(convex_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
					convex_counter++; // ���� �ϰ� �� ������ ����.
					convex_freight_count++;
					convex_hull(); // -> �ٽ� convex_hull�� ���;��Ѵ�.
				}
			}

			else {

				if ((convex_all_sort == false) && (convex_full_time[convex_counter - 1] > convex_vector[convex_idx].create_time)) {
					convex_idx++;
					convex_hull();
				}// ���� �۾��� �����ϰ� ���� ������ ����.

				else {

					for (int i = 0; i < convex_idx; i++) {
						sort(convex_vector.begin(), convex_vector.begin() + convex_idx, x_comp_operation);
					}// ���� �� �߿��� ã�ƾ��Ѵ�. -> ���� ���� �ֱٿ� ������ �ϸ� ��

					cross_product(a.robot[0].x, a.robot[0].y, convex_vector[0]);
					// march up ����.

					if (temp_cross == 1) {
						if (convex_freight_count ==5 ) {
							comp_to_dist.x = a.robot[0].x;
							comp_to_dist.y = a.robot[0].y;
							comp_to_dist.end_x = a.door[0].x;
							comp_to_dist.end_y = a.door[0].y;
							comp_to_dist.request = -1;
							a.robot[0].x = a.door[0].x;
							a.robot[0].y = a.door[0].y;
							convex_full_dist.push_back(convex_first_move_dist);
							convex_full_time.push_back(convex_first_move_time);
							convex_drow_vec.push_back(comp_to_dist);
							convex_freight_count = 0;
							convex_hull();
						}
						else {
							temp_gd = abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y);
							temp_gt = (abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y)) / 10.0;

							comp_to_dist.x = convex_vector[0].x;
							comp_to_dist.y = convex_vector[0].y;
							comp_to_dist.end_x = convex_vector[0].end_x;
							comp_to_dist.end_y = convex_vector[0].end_y;

							a.robot[0].x = convex_vector[0].x;
							a.robot[0].y = convex_vector[0].y; // ������ �κ��� �̵�.

							comp_to_dist.mov = temp_gd;

							comp_to_dist.request = convex_vector[0].request;

							comp_to_dist.end_time = temp_gt + convex_vector[0].create_time;

							matrix[a.robot[0].x][a.robot[0].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

							convex_full_dist.push_back(temp_gd);
							convex_full_time.push_back(temp_gt);

							convex_drow_vec.push_back(comp_to_dist);
							// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
							// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
							convex_vector.erase(convex_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
							convex_counter++; // ���� �ϰ� �� ������ ����.
							convex_freight_count++;
							convex_hull(); // -> �ٽ� convex_hull�� ���;��Ѵ�.
										   // �̷��� ��������� ������ ������ ����� ����� ���ĵ�.
						}

					}
					else {

						sort(convex_vector.begin(), convex_vector.begin() + convex_idx, y_comp_operation);

						if (convex_freight_count == 5) {
							comp_to_dist.x = a.robot[0].x;
							comp_to_dist.y = a.robot[0].y;
							comp_to_dist.end_x = a.door[0].x;
							comp_to_dist.end_y = a.door[0].y;
							comp_to_dist.request = -1;
							a.robot[0].x = a.door[0].x;
							a.robot[0].y = a.door[0].y;
							convex_full_dist.push_back(convex_first_move_dist);
							convex_full_time.push_back(convex_first_move_time);
							convex_drow_vec.push_back(comp_to_dist);
							convex_freight_count = 0;
							convex_hull();
						}
						else{
							temp_gd = abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y);
							temp_gt = (abs(a.robot[0].x - convex_vector[0].x) + abs(a.robot[0].y - convex_vector[0].y)) / 10.0;

							comp_to_dist.x = convex_vector[0].x;
							comp_to_dist.y = convex_vector[0].y;
							comp_to_dist.end_x = convex_vector[0].end_x;
							comp_to_dist.end_y = convex_vector[0].end_y;

							a.robot[0].x = convex_vector[0].x;
							a.robot[0].y = convex_vector[0].y; // ������ �κ��� �̵�.

							comp_to_dist.mov = temp_gd;

							comp_to_dist.request = convex_vector[0].request;

							comp_to_dist.end_time = temp_gt + convex_vector[0].create_time;

							matrix[a.robot[0].x][a.robot[0].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

							convex_full_dist.push_back(temp_gd);
							convex_full_time.push_back(temp_gt);
							
							convex_drow_vec.push_back(comp_to_dist);
							// �� �̵� ��ǥ ���� �� ���� ���Ϳ� �߰�.
							// ���� �ϰ� �� ������ �ð����� ���� �ʿ�. -> �� �Ŀ� ���Ӱ� ���� ��ü ����ؾ���.
							convex_vector.erase(convex_vector.begin()); // �ϳ��� �̵��ϰ�, �������� �ٽ� ��꿡 ������. (comp_vec 0 ���� ��꿡 �̿�.) 
							convex_counter++; // ���� �ϰ� �� ������ ����.
							convex_freight_count++;
							convex_hull(); // -> �ٽ� convex_hull�� ���;��Ѵ�.
										   // �̷��� ��������� ������ ������ ����� ����� ���ĵ�.
						}
					}

				}
			}
		}
	}
	if (convex_counter == convex_size) {
		temp_gd = abs(a.robot[qcounter].x - convex_vector[0].x) + abs(a.robot[qcounter].y - convex_vector[0].y);
		temp_gt = (abs(a.robot[qcounter].x - convex_vector[0].x) + abs(a.robot[qcounter].y - convex_vector[0].y)) / 10.0;

		comp_to_dist.x = convex_vector[0].x;
		comp_to_dist.y = convex_vector[0].y;
		comp_to_dist.end_x = convex_vector[0].end_x;
		comp_to_dist.end_y = convex_vector[0].end_y;
		comp_to_dist.request = convex_vector[0].request;

		a.robot[qcounter].x = convex_vector[0].x;
		a.robot[qcounter].y = convex_vector[0].y; // ������ �κ��� �̵�.

		matrix[a.robot[qcounter].x][a.robot[qcounter].y].moving_checker = true; // moving checker���� �ߺ� ������ ���� flag �����

		convex_full_dist.push_back(temp_gd);
		convex_full_time.push_back(temp_gt);

		greedy_drow_vec.push_back(comp_to_dist);
		for (int i = 0; i < convex_size; i++) {
			convex_total_dist += convex_full_dist[i];
			convex_total_time += convex_full_time[i];
		}
		cout << convex_total_dist << "  " << convex_total_time << endl;
		convex_counter++;
	}
}


int freight_counter = 0;

void elevator() {
	work_vector comp_to_dist;
	float temp_gt = 0, temp_gd = 0;
	int temp_req = 0;
	int temp_cross = 0;
	int temp_idx = 0;
	// ���� ���� work_list ���� comp_vec�� ��� �� �ִ�.

	float first_move_time, first_move_dist;

	first_move_time = (abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y)) / 10.0;
	first_move_dist = abs(first_robot_x - a.door[0].x) + abs(first_robot_y - a.door[0].y);


	if (ele_vector.size() == 1) {
		a.robot[0].x = ele_vector[0].x;
		a.robot[0].y = ele_vector[0].y;
		comp_to_dist.x = ele_vector[0].x;
		comp_to_dist.y = ele_vector[0].y;
		comp_to_dist.end_x = ele_vector[0].end_x;
		comp_to_dist.end_y = ele_vector[0].end_y;
		comp_to_dist.request = ele_vector[0].request;
		el_drow_vec.push_back(comp_to_dist);
	}
	else{
		if (el_counter == 0) {
			comp_to_dist.x = a.robot[0].x;
			comp_to_dist.y = a.robot[0].y;
			comp_to_dist.end_x = a.door[0].x;
			comp_to_dist.end_y = a.door[0].y;
			comp_to_dist.request = -1;
			a.robot[0].x = a.door[0].x;
			a.robot[0].y = a.door[0].y;
			el_full_dist.push_back(first_move_dist);
			el_full_time.push_back(first_move_time);
			el_drow_vec.push_back(comp_to_dist);
			el_counter++;
			elevator();
		} // ������ �̵��ϰ� greedy �Լ��� ���ư� counter ����.
		else if (el_counter == 1) {
			sort(ele_vector.begin(), ele_vector.end(), comp_ctime_func);
			// ���� �ð��� ���� ����
			comp_to_dist.x = ele_vector[0].x;
			comp_to_dist.y = ele_vector[0].y;
			comp_to_dist.end_x = ele_vector[0].end_x;
			comp_to_dist.end_y = ele_vector[0].end_y;
			a.robot[0].x = ele_vector[0].x;
			a.robot[0].y = ele_vector[0].y;
			comp_to_dist.request = ele_vector[0].request;
			el_drow_vec.push_back(comp_to_dist);
			ele_vector.erase(ele_vector.begin());
			freight_counter++;
			el_counter++;
			elevator();
		}
		// ȭ�� ī��Ʈ�� 5�϶��� ������ �������� , �������϶��� ȭ���� 5�� ���϶����� y�� ������ Ž��.
		// 0���� ���������� ����Ž��.
		else if (el_counter != 0 && el_size != 1) {
			sort(ele_vector.begin(), ele_vector.end(), comp_ctime_func);
			// ���� �ð��� ���� ����
			temp_cross = cross_product(a.robot[0].x, a.robot[0].y, ele_vector[0]);

			if (ele_vector[0].request == 0) {
				if (freight_counter == 5) {
					comp_to_dist.x = a.robot[0].x;
					comp_to_dist.y = a.robot[0].y;
					comp_to_dist.end_x = a.door[0].x;
					comp_to_dist.end_y = a.door[0].y;
					comp_to_dist.request = -1;
					el_drow_vec.push_back(comp_to_dist);
					a.robot[0].x = a.door[0].x;
					a.robot[0].y = a.door[0].y;
					freight_counter = 0;
					elevator();
				}
				else {
					if (temp_cross == 1) {
						comp_to_dist.x = ele_vector[0].x;
						comp_to_dist.y = ele_vector[0].y;
						comp_to_dist.end_x = ele_vector[0].end_x;
						comp_to_dist.end_y = ele_vector[0].end_y;
						a.robot[0].x = ele_vector[0].x;
						a.robot[0].y = ele_vector[0].y;
						comp_to_dist.request = ele_vector[0].request;
						el_drow_vec.push_back(comp_to_dist);
						ele_vector.erase(ele_vector.begin());
						el_counter++;
						elevator();
					}
					else {
						for (int i = 0; i < ele_vector.size(); i++) {
							temp_idx++;
							temp_cross = cross_product(a.robot[0].x, a.robot[0].y, ele_vector[i]);
							if (temp_cross = 1) break;
						}
						sort(ele_vector.begin(), ele_vector.begin() + temp_idx, y_comp_operation);
						comp_to_dist.x = ele_vector[0].x;
						comp_to_dist.y = ele_vector[0].y;
						comp_to_dist.end_x = ele_vector[0].end_x;
						comp_to_dist.end_y = ele_vector[0].end_y;
						a.robot[0].x = ele_vector[0].x;
						a.robot[0].y = ele_vector[0].y;
						comp_to_dist.request = ele_vector[0].request;
						el_drow_vec.push_back(comp_to_dist);
						ele_vector.erase(ele_vector.begin());
						freight_counter++;
						el_counter++;
						elevator();
					}
				}
			}
			else {
				if (freight_counter == 5) {
					comp_to_dist.x = a.robot[0].x;
					comp_to_dist.y = a.robot[0].y;
					comp_to_dist.end_x = a.door[0].x;
					comp_to_dist.end_y = a.door[0].y;
					comp_to_dist.request = -1;
					el_drow_vec.push_back(comp_to_dist);
					a.robot[0].x = a.door[0].x;
					a.robot[0].y = a.door[0].y;
					freight_counter = 0;
					elevator();
				}
				else {
					sort(ele_vector.begin(), ele_vector.end(), y_comp_operation);
					comp_to_dist.x = ele_vector[0].x;
					comp_to_dist.y = ele_vector[0].y;
					comp_to_dist.end_x = ele_vector[0].end_x;
					comp_to_dist.end_y = ele_vector[0].end_y;
					a.robot[0].x = ele_vector[0].x;
					a.robot[0].y = ele_vector[0].y;
					comp_to_dist.request = ele_vector[0].request;
					el_drow_vec.push_back(comp_to_dist);
					ele_vector.erase(ele_vector.begin());
					freight_counter++;
					el_counter++;
					elevator();
					}
				}
			}
		}
}

void draw_matrix(vector <work_vector> drow_vec) {
	work_vector test;
	liner temp;

	if (work_counter > 30) {

		if (qcounter == 0) {
			temp.endX = first_robot_x;
			temp.endY = first_robot_y;
		}
		else if (qcounter == 1) {
			temp.endX = second_robot_x;
			temp.endY = second_robot_y;
		}
		else if (qcounter == 2) {
			temp.endX = third_robot_x;
			temp.endY = third_robot_y;
		}
		else {
			temp.endX = forth_robot_x;
			temp.endY = forth_robot_y;
		}



		temp.startX = a.door[0].x;
		temp.startY = a.door[0].y;
		linevec.push_back(temp);
		glutPostRedisplay();



		for (int i = 0; i < drow_vec.size() - 1; i++) {
			//DrawLine(drow_vec[i].)
			if (drow_vec[i].request == 0 || drow_vec[i].request == 2) { //����
				if (drow_vec[i + 1].request == 0 || drow_vec[i + 1].request == 2) {//����
					DrawLine(drow_vec[i].x, drow_vec[i].y, drow_vec[i + 1].x, drow_vec[i + 1].y);
					temp.startX = drow_vec[i].x;
					temp.startY = drow_vec[i].y;
					temp.endX = drow_vec[i + 1].x;
					temp.endY = drow_vec[i + 1].y;
					if (i == 0) {
						temp.startX = a.door[0].x;
						temp.startY = a.door[0].y;
					}
					linevec.push_back(temp);
					glutPostRedisplay();
				}
				else {//����
					DrawLine(drow_vec[i].x, drow_vec[i].y, drow_vec[i + 1].end_x, drow_vec[i + 1].end_y);
					temp.startX = drow_vec[i].x;
					temp.startY = drow_vec[i].y;
					temp.endX = drow_vec[i + 1].end_x;
					temp.endY = drow_vec[i + 1].end_y;
					linevec.push_back(temp);
					if (i == 0) {
						temp.startX = a.door[0].x;
						temp.startY = a.door[0].y;
					}
					glutPostRedisplay();
				}
			}
			else { // ����
				if (drow_vec[i + 1].request == 0 || drow_vec[i + 1].request == 2) {//����
					DrawLine(drow_vec[i].end_x, drow_vec[i].end_y, drow_vec[i + 1].x, drow_vec[i + 1].y);
					temp.startX = drow_vec[i].end_x;
					temp.startY = drow_vec[i].end_y;
					temp.endX = drow_vec[i + 1].x;
					temp.endY = drow_vec[i + 1].y;
					if (i == 0) {
						temp.startX = a.door[0].x;
						temp.startY = a.door[0].y;
					}
					linevec.push_back(temp);
					glutPostRedisplay();
				}
				else {//����
					DrawLine(drow_vec[i].end_x, drow_vec[i].end_y, drow_vec[i + 1].end_x, drow_vec[i + 1].end_y);
					temp.startX = drow_vec[i].end_x;
					temp.startY = drow_vec[i].end_y;
					temp.endX = drow_vec[i + 1].end_x;
					temp.endY = drow_vec[i + 1].end_y;
					linevec.push_back(temp);
					if (i == 0) {
						temp.startX = a.door[0].x;
						temp.startY = a.door[0].y;
					}
					glutPostRedisplay();
				}
			}
		}

		DrawLine(linevec[linevec.size() - 1].endX, linevec[linevec.size() - 1].endY, a.door[0].x, a.door[0].y);
		temp.startX = linevec[linevec.size() - 1].endX;
		temp.startY = linevec[linevec.size() - 1].endY;
		temp.endX = a.door[0].x;
		temp.endY = a.door[0].y;
		linevec.push_back(temp);

		greedy_total_dist = 0;

		cout << endl << "�̵� ���� ���" << endl;
		for (int i = 0; i < linevec.size(); i++) {
			if (i == 0) {
				//cout << linevec[i].endX << "," << linevec[i].endY << "," << linevec[i].startX << "," << linevec[i].startY << endl;
				cout << "��ǥ �̵� ���� : (" << linevec[i].endX << "," << linevec[i].endY << ") ���� (" << linevec[i].startX << "," << linevec[i].startY << ")�� �̵�" << endl;
			}
			//cout << linevec[i].startX << "," << linevec[i].startY << "," << linevec[i].endX << "," << linevec[i].endY << endl;
			cout << "��ǥ �̵� ���� : (" << linevec[i].startX << "," << linevec[i].startY << ") ���� (" << linevec[i].endX << "," << linevec[i].endY << ")�� �̵�" << endl;

			greedy_total_dist += abs(linevec[i].endX - linevec[i].startX) + abs(linevec[i].endY - linevec[i].startY);
			//radius = 10;
			glColor3f(1, 0, 0);
			if (map[linevec[i].endX][linevec[i].endY] != Door) {
				//renderBitmapCharacher(cos(1)*radius + (x * termW) -10, sin(0)*radius + (y * termH)-5, 0, (void *)font, "x");


			}
		}
		
		
		greedy_total_time = greedy_total_dist / 10;
		greedy_total_time = greedy_total_time + adder + 120;
		average_wating_time = greedy_total_time / 30 + quantization;
		glutDisplayFunc(display);
		//t5("greedy");

		return;
	}
}

void divide_greedy(int position) {
	greedy_fin = false;
	greedy_drow_vec.clear();
	greedy_counter = 0;
	copy_vector.clear();
	copy_vector = copy_divider[position];
	copy_size = copy_vector.size();
	greedy();
}

void divide_greedy2(int position) {
	int i = 0;
	if (position == 0) i = 0;
	else i = 2;
	greedy_fin = false;
	greedy_drow_vec.clear();
	greedy_counter = 0;
	copy_vector.clear();
	copy_vector = copy_divider[i];
	for (int j = 0; j < copy_divider[i + 1].size(); i++) {
		copy_vector.push_back(copy_divider[i + 1][j]);
	}
	
	copy_size = copy_vector.size();
	greedy();
}

void random_greedy(int position) {
	greedy_drow_vec.clear();
	greedy_counter = 0;
	copy_vector.clear();
	copy_vector = copy_random_divider[position];
	copy_size = copy_vector.size();
	greedy();
}
void row_greedy(int position) {
	greedy_drow_vec.clear();
	greedy_counter = 0;
	copy_vector.clear();
	copy_vector = row[position];
	copy_size = copy_vector.size();
	greedy();
}
void col_greedy(int position) {
	greedy_drow_vec.clear();
	greedy_counter = 0;
	copy_vector.clear();
	copy_vector = col[position];
	copy_size = copy_vector.size();
	greedy();
}



void divide_hull(int position) {
	C_flag = true;
	F_flag = false;
	B_flag = false;
	glutReshapeFunc(0);
	glutDisplayFunc(display);
	glutReshapeFunc(0);
	linevec.clear();
	convex_drow_vec.clear();
	convex_counter = 0;
	copy_vector.clear();
	convex_vector = copy_divider[position];
	copy_size = copy_vector.size();
	convex_size = convex_vector.size();
	convex_hull();
}

void col_convex(int position) {
	C_flag = true;
	F_flag = false;
	B_flag = false;
	convex_size = convex_vector.size();
	glutReshapeFunc(0);
	glutDisplayFunc(display);
	glutReshapeFunc(0);
	linevec.clear();
	convex_drow_vec.clear();
	convex_counter = 0;
	copy_vector.clear();
	convex_vector = col[position];
	copy_size = copy_vector.size();
	convex_size = convex_vector.size();
	convex_hull();
}

void row_convex(int position) {
	C_flag = true;
	F_flag = false;
	B_flag = false;
	convex_size = convex_vector.size();
	glutReshapeFunc(0);
	glutDisplayFunc(display);
	glutReshapeFunc(0);
	linevec.clear();
	convex_drow_vec.clear();
	convex_counter = 0;
	copy_vector.clear();
	convex_vector = row[position];
	copy_size = copy_vector.size();
	convex_size = convex_vector.size();
	convex_hull();
}

void rand_convex(int position) {
	C_flag = true;
	F_flag = false;
	B_flag = false;
	convex_size = convex_vector.size();
	glutReshapeFunc(0);
	glutDisplayFunc(display);
	glutReshapeFunc(0);
	linevec.clear();
	convex_drow_vec.clear();
	convex_counter = 0;
	copy_vector.clear();
	convex_vector = copy_random_divider[position];
	copy_size = copy_vector.size();
	convex_size = convex_vector.size();
	convex_hull();
}

int case_counter[20] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };




void DoKeyboard(unsigned char key, int x, int y)
{
	

	//thread t7(t5, "abc");
	switch (key) {
	
	case 'H':
	case 'h':
		half_flag = true;
		command_color = 4;
		linevec.clear();

		C_flag = false;
		F_flag = false;
		B_flag = true;
		greedy_total_dist = 0;
		greedy_total_time = 0;
		divide_greedy2(hcounter);

		capture_counter = greedy_drow_vec.size() + 1;
		draw_matrix(greedy_drow_vec);
		hcounter++;
		hcounter = hcounter % 2;

		break;
	case 'e':
	case 'E':
		half_flag = false;
		command_color = 0;
		case_counter[0]++;
		linevec.clear();
		if (el_drow_vec.size() == 0) {
			el_drow_vec.clear();
			elevator();
		}
		C_flag = true;
		
		draw_matrix(el_drow_vec);
		glutDisplayFunc(display);
		glutPostRedisplay();
		capture_counter = case_counter[0];
	
		if (case_counter[0] == el_drow_vec.size()+1)
			case_counter[0] = 0;
		break;
		
	case 'f':
	case 'F':
		half_flag = false;
		//drow_vec.clear();
		case_counter[1]++;
		fout_flag = true;
		command_color = 1;
		C_flag = false;
		F_flag = true;
		B_flag = false;
		fifo2();
		linevec.clear();
		draw_matrix(drow_vec);
		//drow_vec.pop_back();
		capture_counter = case_counter[1];
		glutDisplayFunc(display);
		glutPostRedisplay();


		
		if (case_counter[1] == drow_vec.size()+1)
			case_counter[1] = 0;
		fin = true;
		break;
	case 'b':
	case 'B':
		half_flag = false;
		case_counter[2]++;
		command_color = 3;
		//if (copy_vector.size() > 31)copy_paste = copy_vector;
		//else if (copy_vector.size() < 30) copy_vector = copy_paste;
		qcounter = 0;
		copy_size = copy_vector.size();
		C_flag = false;
		F_flag = false;
		B_flag = true;
		greedy_counter = 0;
		//greedy_drow_vec.clear();
		glutReshapeFunc(0);
		glutDisplayFunc(display);
		linevec.clear();
		greedy();
		capture_counter = case_counter[2];
		draw_matrix(greedy_drow_vec);
		
		if (case_counter[2] == greedy_drow_vec.size()+1)
			case_counter[2] = 0;
		greedy_fin = true;
		break;
	case 'c':
	case 'C':
		half_flag = false;
		case_counter[3]++;
		if (convex_vector.size() > 31) copy_convex_paste = convex_vector;
		else if (convex_vector.size() < 30) convex_vector = copy_convex_paste;
	
		command_color = 2;
		C_flag = true;
		F_flag = false;
		B_flag = false;
		convex_counter = 0;
		//convex_drow_vec.clear();
		convex_size = convex_vector.size();
		glutReshapeFunc(0);
		glutDisplayFunc(display);
		glutReshapeFunc(0);
		linevec.clear();
		convex_hull();
		capture_counter = case_counter[3];
		//->convex_hull���� ������ ��κ��͸� �Ʒ� drow_vec�ڸ��� �־��ָ��
		draw_matrix(convex_drow_vec);
		
		if (case_counter[3] == convex_drow_vec.size()+1)
			case_counter[3] = 0;
		
		convex_fin = true;
		break;
		
	case 'q':
	case 'Q':
		half_flag = true;
		command_color = 4;
		linevec.clear();
	
		C_flag = false;
		F_flag = false;
		B_flag = true;
		greedy_total_dist = 0;
		greedy_total_time = 0;
		divide_greedy(qcounter);

		capture_counter = greedy_drow_vec.size()+1;
		draw_matrix(greedy_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;
		break;
	case 'o':
	case 'O':
		half_flag = true;
		command_color = 6;
		linevec.clear();
		C_flag = false;
		F_flag = false;
		B_flag = true;
		greedy_total_dist = 0;
		greedy_total_time = 0;
		row_greedy(qcounter);
		capture_counter = greedy_drow_vec.size()+1;
		draw_matrix(greedy_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;

		break;
	case 'P':
	case 'p':
		half_flag = true;
		command_color = 7;
		linevec.clear();
		C_flag = false;
		F_flag = false;
		B_flag = true;

		greedy_total_dist = 0;
		greedy_total_time = 0;

		col_greedy(qcounter);
		capture_counter = greedy_drow_vec.size()+1;
		draw_matrix(greedy_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;

		break;
	case 'D':
	case 'd':
		half_flag = true;
		command_color = 5;
		linevec.clear();
		C_flag = false;
		F_flag = false;
		B_flag = true;
		greedy_total_dist = 0;
		greedy_total_time = 0;
		random_greedy(qcounter);
		capture_counter = greedy_drow_vec.size() +1;
		draw_matrix(greedy_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;
		break;


	case 'z':
	case 'Z':
		half_flag = true;
		convex_fin = false;
		command_color = 8;
		divide_hull(qcounter);
		capture_counter = convex_drow_vec.size()+1;
		draw_matrix(convex_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;
		break;
	case 'x':
	case 'X':
		half_flag = true;
		convex_fin = false;
		command_color = 9;
		col_convex(qcounter);
		capture_counter = convex_drow_vec.size()+1;
		draw_matrix(convex_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;
		break;
	case 'n':
	case 'N':
		half_flag = true;
		convex_fin = false;
		command_color = 10;
		row_convex(qcounter);
		capture_counter = convex_drow_vec.size()+1;
		draw_matrix(convex_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;
		break;
	case 'M':
	case 'm':
		half_flag = true;
		convex_fin = false;
		command_color = 11;
		rand_convex(qcounter);
		capture_counter = convex_drow_vec.size()+1;
		draw_matrix(convex_drow_vec);
		qcounter++;
		qcounter = qcounter % 4;
		break;

	case 'r':
	case 'R':

		C_flag = false;
		F_flag = false;
		B_flag = false;
		glutReshapeFunc(0);
		glutInitWindowPosition(500, 0);
		glutReshapeWindow(900, 750);

		glutDisplayFunc(display);


		glutPostRedisplay();
		//glutSwapBuffers();

		//glutMainLoop();
		//glutDisplayFunc(display);
		//   glutDestroyWindow(3);
		break;
	case 'g':
	case 'G':

		C_flag = false;
		F_flag = false;
		B_flag = false;
		//t7.join();
		glutReshapeFunc(0);
		glutReshapeWindow(1300, 1000);
		display();
		glutDisplayFunc(display);
		//glutSwapBuffers();
		glutPostRedisplay();
		glutMainLoop();
		break;

	default:
		C_flag = false;
		F_flag = false;
		B_flag = false;
	}
	glutPostRedisplay();
}
int cal_counter = 0;

void caculator(string msg) {

	thread task_sorting(task_sorting, "string");
	task_sorting.join();
	//fifo();
	//draw_matrix(drow_vec);

	//cal_counter++;
	if (cal_counter == 30) {
		//greedy();
	}
}


void command_checker(string msg) { // ������ ���Ƽ� ������ �����Ǿ����� ����(���ɾ� ���� ����)

	checker = 5;
	
	DrawStone(a.door[0].x, a.door[0].y);
	renderBitmapCharacher(cos(1)*radius + (a.door[0].x * termW) - 10, sin(0)*radius + (a.door[0].y * termH) - 5, 0, (void *)font, "Door");
	//radius = 10;
	glutPostRedisplay();
	checker = 7;
	for (int i = 0; i < a.robot_num; i++) {
		DrawStone(a.robot[i].x, a.robot[i].y);
		glutPostRedisplay();
	}
	checker = 0;
	for (int i = 0; i < a.freight.size(); i++) {
		DrawStone(a.freight[i].x, a.freight[i].y);
		glutPostRedisplay();
	}

	glutPostRedisplay();
	random_device rd;
	mt19937 mt(rd()); //�ξ� ����
	uniform_int_distribution<int> dist(0, 2);
	work_vector temp;
	checker = dist(mt);
	temp.request = checker;
	bool same;
	//   cout << checker << " ���ɾ� ��: " << work_counter << endl;
	if (checker == 1) { // �������� : �Ա� ��ġ�߿� �������� �ϳ��� �����ǰ�, �̵��Ǵ� ��ġ�� ȭ���� �������. ( matrix �� �߰� �ʿ�)
						//cout << "���� ���� :" << endl;

		uniform_int_distribution<int> distq(0, a.door.size() - 1);

		int t = distq(mt); //������ ����
		temp.x = a.door[t].x;
		temp.y = a.door[t].y;

		uniform_int_distribution<int> dist2(1, 39);
		do {
			same = false;
			int random_x = dist2(mt); //������ x
			temp.end_x = dist2(mt);
			Sleep(1);
			int random_y = dist2(mt); //������ y
			temp.end_y = dist2(mt);
			temp.create_time = timer;
			temp.end_time = -1;
			for (int i = 0; i < work_list.size(); i++) {
				if (work_list[i].end_x == temp.end_x && work_list[i].end_y == temp.end_y) {
					same = true;
				}

			}
			if (work_list.size() == 0) same = false;
		} while (same == true);
		cout << "�����ð� : " << timer << " ��ġ - x : " << temp.x << ". y : " << temp.y << "�� �Ա����� : (" << temp.end_x << "," << temp.end_y << ") ��ġ�� ����" << endl;
		DrawStone(temp.end_x, temp.end_y);
		//DrawLine(temp.x, temp.y, temp.end_x, temp.end_y);
		glutPostRedisplay();
		work_list.push_back(temp);
	}
	else if (checker == 2) { //���� ȭ���� �����ϴ� ��ġ �� �ϳ��� �������� ����, �̵��Ǵ� ��ġ�� ȭ���� ����� ��. (matrix�� �̵� �ʿ�)
							 //cout << "�̵� ���� :" << endl;
		int f_size = a.freight.size() - 1;
		uniform_int_distribution<int> dist3(0, f_size);

		do {
			same = false;
			int t = dist3(mt);
			temp.x = a.freight[t].x; //������ ����
			temp.y = a.freight[t].y; //y
			temp.create_time = timer;
			temp.end_time = -1;
			temp.end_x = temp.x;
			temp.end_y = temp.y;
			for (int i = 0; i < work_list.size(); i++) {
				if (work_list[i].x == temp.x && work_list[i].y == temp.y) {
					same = true;

				}

			}
			if (work_list.size() == 0) same = false;
		} while (same == true);
		cout << "�����ð� : " << timer << " ��ġ - x : " << temp.x << ". y : " << temp.y << "�� ȭ���� ��ġ�� �̵�" << endl;
		DrawStone(temp.x, temp.y);
		//DrawStone(temp.end_x, temp.end_y);
		//DrawLine(temp.x, temp.y, temp.end_x, temp.end_y);
		work_list.push_back(temp);

	}
	else { //���� ȭ���� �����ϴ� ��ġ �� �ϳ��� �������� ����, �̵��Ǵ� ��ġ�� �Ա� ��ġ�� ���� ����� ��ġ���� ����. (matrix�� ���� �ʿ�)

		   //cout << "���� ���� :" << endl;//(����� ���� ����� ��ȭ�� ������ �迭�� ������� �������� �����ϵ��� ���� �ʿ� - ���� ��ǥ�� ������ �ʿ䰡 ����)

		int f_size = a.freight.size() - 1;
		do {
			same = false;
			uniform_int_distribution<int> dist3(0, f_size);
			int f = dist3(mt);
			temp.x = a.freight[f].x;
			temp.y = a.freight[f].y;
			for (int i = 0; i < work_list.size(); i++) {
				if (work_list[i].x == temp.x && work_list[i].y == temp.y) {
					same = true;

				}

			}
			if (work_list.size() == 0) same = false;
		} while (same == true);
		uniform_int_distribution<int> distq(0, a.door.size() - 1);
		int t = distq(mt); //������ ����
		temp.end_x = a.door[t].x;
		temp.end_y = a.door[t].y;
		temp.create_time = timer;
		temp.end_time = -1;
		cout << "�����ð� : " << timer << " ��ġ - x : " << temp.x << ". y : " << temp.y << "�� ȭ���� : (" << temp.end_x << "," << temp.end_y << ") �ⱸ�� �̵��Ͽ� ����" << endl;
		DrawStone(temp.x, temp.y);
		//DrawLine(temp.x, temp.y, temp.end_x, temp.end_y);
		glutPostRedisplay();
		work_list.push_back(temp);
	}

	/*   if (matrix[random_y][random_x].now_freightPosition == true) {

	}
	*/
	thread t4(caculator, "asdf");
	if (t4.joinable()) {
		t4.join();
		counter++;
	}
	else
		return;
}


// ���Ƽ� ����
int task1_checker = 0;
void poisson_maker(string msg) // ���Ƽ� ����
{
	const int nrolls = 10000; // number of experiments
	const int nstars = 100;   // ����

	std::default_random_engine generator;
	int x;

	while (1) {
		if (work_counter > 30) return;
		x = 5;

		std::poisson_distribution<int> distribution(x); // ���� ���� ���� ������ �ٲ� (���)

		int p[200] = {};

		for (int i = 0; i < nrolls; ++i) {
			int number = distribution(generator);
			if (number < 200) ++p[number];
		}

		//std::cout << "poisson_distribution (mean= " << x << " ):" << std::endl;
		double counter = 0;
		for (int i = 0; i < 100; ++i) {
			double s;

			s = p[i] * double(nstars) / double(nrolls);
			counter += s;
			double percent = counter * 100 / nstars;
			int per = floor(percent);
			int testvec[200] = { 0 };
			for (int i = 0; i < per; i++) {
				testvec[i] = 1;
			}
			/*for (int i = per; i < 100; i++) {
			testvec[i] = 0;
			}
			*/
			int random_checker = rand() % 100;
			timer++;
			//cout << timer;

			//   std::cout << i << ": \t" << s << "%\t, ���� ���� : " << percent << "%";

			if (testvec[random_checker] == 1) {
				//      cout << "\t����" << endl;
				create_flag = true;

				thread t3(command_checker, "wtf");
				t3.join();
				break;

			}
			//   else cout << "\t���" << endl; create_flag = false;


			Sleep(50);

		}
		task1_checker++;
		if (task1_checker > 30) return;
	}
	return;
}

//�⺻ �ʵ� ���� �� �⺻ ���� ����
void default_setup(string msg) {

	a.make_door();
	a.make_robot();
	a.make_freight();
	first_robot_x = a.robot[0].x;
	first_robot_y = a.robot[0].y;
	second_robot_x = a.robot[1].x;
	second_robot_y = a.robot[1].y;

	third_robot_x = a.robot[2].x;
	third_robot_y = a.robot[2].y;

	forth_robot_x = a.robot[3].x;
	forth_robot_y = a.robot[3].y;

	fout.open("connect.out");


}

int main(int argc, char* argv[]) {
	// �� �����带 ����� �����մϴ�. ���� �����尡 block���� �ʽ��ϴ�.
	
	adder = rand() % 10;
	quantization = rand() % 3+5;
	for (int i = 0; i < 100; i++) {
		for (int j = 0; j < 100; j++) {
			matrix[i][j].moving_checker = false;
		}
	}
	default_setup("task2_setup");
	thread t1(poisson_maker, "thread_1 setup");
	//thread t2(t5, "greed");
	t5("greed");

	// main�̰� ���� ���� �����尡 ���� ��ĥ ������ ��ٸ��� ����ϴ�.
	t1.join();
	//t2.join();

	//glutMainLoop();
	cout << 1;
	//t2.join();
}